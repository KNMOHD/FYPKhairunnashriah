import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RHomePage } from '../r-home/r-home';

@Component({
  selector: 'page-r-self',
  templateUrl: 'r-self.html'
})
export class RSelfPage {
	/**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

   /**
    * @name rself
    * @type {Array}
    * @public
    * @description    The list of Session
    */
   public rselfs  :  Array<any> = [];

  /**
     *@name matric
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public matric                 : any; 

  constructor(public navCtrl    : NavController, 
              public NP         : NavParams,
              public toastCtrl  : ToastController,
              public http       : HttpClient,
              public navParams  : NavParams) {

  this.matric = navParams.get('matric');
  
  console.log(this.matric);  
  }
  
  ionViewDidLoad() {

    let   matricID = this.matric,
          headers     : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
          options   : any    = { "key" : "getRSelf", "matricID": matricID},
          url       : any    = this.baseURI + "retrieve-data.php";

          this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
        {
          console.log(data);
          this.rselfs = data;
        },
        (error : any) =>
        {
           this.sendNotification('Get Info Failed');
        })
  }

  sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
   }
  goToRHome(){
    this.navCtrl.push(RHomePage);
  }

}