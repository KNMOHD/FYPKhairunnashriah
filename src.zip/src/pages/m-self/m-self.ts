import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { MHomePage } from '../m-home/m-home';

@Component({
  selector: 'page-m-self',
  templateUrl: 'm-self.html'
})
export class MSelfPage {
/**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

   /**
    * @name mself
    * @type {Array}
    * @public
    * @description    The list of Session
    */
   public mselfs  :  Array<any> = [];

  /**
     *@name matric
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public matric               : any; 

  constructor(public navCtrl    : NavController, 
              public NP         : NavParams,
              public toastCtrl  : ToastController,
              public http       : HttpClient,
              public navParams  : NavParams) {

  this.matric = navParams.get('matric');
  
  console.log(this.matric);  
  }
  
  ionViewDidLoad() {

    let   matricID = this.matric,

    //setting the connection
          headers     : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
          options   : any    = { "key" : "getMSelf", "matricID": matricID},
          url       : any    = this.baseURI + "retrieve-data.php";

          this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
        {
          console.log(data);
          this.mselfs = data;
        },
        (error : any) =>
        {
           this.sendNotification('Get Info Failed');
        })
  }

  sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
   }
   
  goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }

}