import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { MHomePage } from '../m-home/m-home';
import { MGroupPage } from '../m-group/m-group';

@Component({
  selector: 'page-m-enroll',
  templateUrl: 'm-enroll.html'
})
export class MEnrollPage {

  /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

   /**
    * @name groups
    * @type {Array}
    * @public
    * @description    The list of Session
    */
   public groups  :  Array<any> = [];

     matric:string;

    constructor(public navCtrl    : NavController, 
                public NP         : NavParams,
                public toastCtrl  : ToastController,
                public http       : HttpClient,
                public navParams  : NavParams) {
      this.matric = navParams.get('matric'); //terima matric

    console.log(this.matric);
  }

  ionViewDidLoad() {

    let headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
        options   : any    = { "key" : "loadLiqagroup"},
        url       : any    = this.baseURI + "retrieve-data.php";

        this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
      {
        console.dir(data);
        this.groups =data;
      },
      (error : any) =>
      {
         this.sendNotification('Get Group Failed lah');
      })
  }

  enrol(group_code){

    let group = group_code,
        matric = this.matric,

        headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
        options   : any    = { "key" : "enroll", "group_code" : group, "matric" : matric},
        url       : any    = this.baseURI + "retrieve-data.php";

        this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
      {
        this.sendNotification(data.message);
      },
      (error : any) =>
      {
         this.sendNotification('Get Group Failed');
      })
  }
  
  sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
   }


  goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }goToMGroup(params){
    if (!params) params = {};
    this.navCtrl.push(MGroupPage);
  }goToMEnroll(params){
    if (!params) params = {};
    this.navCtrl.push(MEnrollPage);
  }
}
