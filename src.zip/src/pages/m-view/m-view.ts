import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { MHomePage } from '../m-home/m-home';
import { MSessionPage } from '../m-session/m-session';

@Component({
  selector: 'page-m-view', 
  templateUrl: 'm-view.html'
})
export class MViewPage {

	public matric    : string;
  public records   : string;

  private baseURI               : string = "http://idlanzikri.com/"

  constructor(public navCtrl    : NavController,
  			      public navParams  : NavParams,
              public http       : HttpClient,
              public toastCtrl  : ToastController) {
  	
    this.matric = navParams.get('matric'); //hantar matric
    console.log("This is Marus with Matric No" + this.matric);
  }

  ionViewDidLoad() {
    let matric  = this.matric,

        //setting the connection
        headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
        options   : any    = { "key" : "getMRecord", "matric": matric},
        url       : any    = this.baseURI + "retrieve-data.php";
      
    this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
    {
      console.log(data);
      this.records = data;
    }, (err) => {
        console.log('Error: ', err);
    });
  }
  /**
    * Manage notifying the user of the outcome of remote operation
    *
    * @public
    * @method sendNotification
    * @param message (String)          message to be dislayed in the notification
    * @return (None)
    */
    sendNotification(message : string)  : void
    {
      let notification = this.toastCtrl.create({
        message    : message,
        duration   : 3000
      });
      notification.present();
    }




  goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }
}
