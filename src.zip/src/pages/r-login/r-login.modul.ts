import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RLoginPage } from './r-login';

@NgModule({
  declarations: [
    RLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(RLoginPage),
  ],
})
export class RLoginPageModule {}