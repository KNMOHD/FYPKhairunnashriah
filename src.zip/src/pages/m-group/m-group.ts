import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { MEnrollPage } from '../m-enroll/m-enroll';
import { MHomePage } from '../m-home/m-home';

@Component({
  selector: 'page-m-group',
  templateUrl: 'm-group.html'
})
export class MGroupPage {

  constructor(public navCtrl: NavController) {
  }



  goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }
}
