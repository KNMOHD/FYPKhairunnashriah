import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RHomePage } from '../r-home/r-home';
import { RDisplayPage } from '../r-display/r-display';

@Component({
  selector: 'page-r-update',
  templateUrl: 'r-update.html'
})

export class RUpdatePage {

  /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

   /**
    * @name items
    * @type {Array}
    * @public
    * @description    The list of Session
    */
   public sessions  :  Array<any> = [];



  constructor(public navCtrl    : NavController, 
              public NP         : NavParams,
              public toastCtrl  : ToastController,
              public http       : HttpClient) {}

  ionViewDidLoad() {
    //console.log("hi");
    //get the session list once the page is loaded
    let headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
        options   : any    = { "key" : "getSession"},
        url       : any    = this.baseURI + "retrieve-data.php";

        this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
      {
        //console.dir(data);
        this.sessions =data;
      },
      (error : any) =>
      {
         this.sendNotification('Get Session Failed');
      });
  }

  sendNotification(message : string)  : void{
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
  }

  itemSelected(item: string) {
    console.log("Selected Item", item);
  }


  goToHome(){
    this.navCtrl.push(RHomePage);
  }

  display(id){
    //console.log(id);
    this.navCtrl.push(RDisplayPage,{
      session_id:id
    });
  }

}