import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { MHomePage } from '../m-home/m-home';
import { MGroupPage } from '../m-group/m-group';
import { MEnrollPage } from '../m-enroll/m-enroll';

@Component({
  selector: 'page-m-ruasa',
  templateUrl: 'm-ruasa.html'
})
export class MRuasaPage {

  constructor(public navCtrl: NavController) {
  }
  


  goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }
}
