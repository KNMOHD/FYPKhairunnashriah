import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MLoginPage } from './m-login';

@NgModule({
  declarations: [
    MLoginPage,
  ],
  imports: [
    IonicPageModule.forChild(MLoginPage),
  ],
})
export class MLoginPageModule {}