import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { MHomePage } from '../m-home/m-home';
import { UserPage } from '../user/user';

@Component({
  selector: 'page-m-login',
  templateUrl: 'm-login.html'
})
export class MLoginPage {
/**
    * @name form
    * @type {FormGroup}
    * @public
    * @description     Define FormGroup property for managing form validation / data retrieval
    */
   public form                   : FormGroup;

/**
     *@name pemail
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public matric                 : any; 

   /**
     *@name password
     *@type {Any}
     *@public
     *@description    Model for managing password field
     */
    public password              : any; 

  /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

  constructor(public navCtrl    : NavController, 
              public navParams  : NavParams,
              public fb         : FormBuilder,
              public toastCtrl  : ToastController,
              public http       : HttpClient) {

                this.form = fb.group({
                  "matric"     : ["",Validators.required],
                  "password"   : ["",Validators.required]
                });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MLoginPage');
  }

  //panggil
  signIn(){
    let matric    : string  = this.form.controls["matric"].value,
        password  : string  = this.form.controls["password"].value,

          headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
          options   : any    = { "key" : "mlogin", "matric" : matric, "password" : password },
          url       : any    = this.baseURI + "retrieve-data.php";

          this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
      {
        if(data.username != null){
          this.navCtrl.push(MHomePage,{ 
            matric:data.matric
          });
        }else{
          this.sendNotification(data.message);
        }
      },
      (error : any) =>
      {
         this.sendNotification('Something went wrong!');
      });
  }

  sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
   }
}
