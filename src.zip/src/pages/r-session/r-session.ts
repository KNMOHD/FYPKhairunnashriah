import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

/*import { BarcodeScanner } from '@ionic-native/barcode-scanner';*/

import { RHomePage } from '../r-home/r-home';
import { RUpdatePage } from '../r-update/r-update';
import { RDisplayPage } from '../r-display/r-display';

@Component({
  selector: 'page-r-session',
  templateUrl: 'r-session.html'
})
export class RSessionPage {

/**
    * @name session
    * @type {FormGroup}
    * @public
    * @description     Define FormGroup property for managing form validation / data retrieval
    */
   public session            : FormGroup;

  /**
     *@name topic
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public topic                 : any; 

  /**
     *@name date
     *@type {Any}
     *@public
     *@description    Model for managing password field
     */
    public date              : any; 

  /**
     *@name time
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public time                 : any;

  /**
     *@name venue
     *@type {Any}
     *@public
     *@description    Model for managing id field
     */
    public venue                 : any;

  /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */



   private baseURI               : string  = "http://idlanzikri.com/";

  matric:string;
  constructor(public navCtrl    : NavController, 
              public NP         : NavParams,
              public fb         : FormBuilder,
              public toastCtrl  : ToastController,
              public http       : HttpClient,
              public navParams  : NavParams) {

  this.matric = navParams.get('matric');
  
  console.log(this.matric);  

                this.session = fb.group({
                  "topic"  : ["",Validators.required],
                  "date"   : ["",Validators.required],
                  "time"   : ["",Validators.required],
                  "venue"  : ["",Validators.required]
                });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RSessionPage');
  }

  createSession(){
    let topic : string  = this.session.controls["topic"].value,
        date  : string  = this.session.controls["date"].value,
        time  : string  = this.session.controls["time"].value,
        venue : string  = this.session.controls["venue"].value,

        headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
        options   : any    = { "key" : "rsession", "topic" : topic, "date" : date, "time" : time, "venue" : venue},
        url       : any    = this.baseURI + "retrieve-data.php";

        this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
      {
        this.sendNotification(data.message);
      },
      (error : any) =>
      {
         this.sendNotification('Create Session Failed');
      });
  }

  setUpperTopic(topic) {
    this.topic = topic.toUpperCase();
  }

  setUpperVenue(venue) {
    this.venue = venue.toUpperCase();
  }


  sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000
      });
      notification.present();
  }


  goToRUpdatePage() {
    //causing the nav controller to animate the new page in
    this.navCtrl.push(RUpdatePage);
  }


  goToRHome(params){
    if (!params) params = {};
    this.navCtrl.push(RHomePage);
  }
}