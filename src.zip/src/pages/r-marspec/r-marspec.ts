import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { RHomePage } from '../r-home/r-home';
import { RMarusPage } from '../r-marus/r-marus';

@Component({
  selector: 'page-r-marspec',
  templateUrl: 'r-marspec.html'
})
export class RMarspecPage {

  constructor(public navCtrl: NavController) {
  }


  goToRHome(params){
    if (!params) params = {};
    this.navCtrl.push(RHomePage);
  }
}
