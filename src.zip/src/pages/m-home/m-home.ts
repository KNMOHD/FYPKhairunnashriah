import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { UserPage } from '../user/user';
import { MLoginPage } from '../m-login/m-login';
import { MSelfPage } from '../m-self/m-self';
import { MGroupPage } from '../m-group/m-group';
import { MEnrollPage } from '../m-enroll/m-enroll';
import { MRuasaPage } from '../m-ruasa/m-ruasa';
import { MSessionPage } from '../m-session/m-session';
import { MViewPage } from '../m-view/m-view';

@Component({
  selector: 'page-m-home',
  templateUrl: 'm-home.html'
})
export class MHomePage {

  public matric    : string;
  public groupID   : string;

  constructor(public navCtrl: NavController,
              public navParams: NavParams) {
    this.matric = navParams.get('matric'); //hantar matric

    console.log(this.matric);
  }

  goToMEnroll(){
    this.navCtrl.push(MEnrollPage,{
            matric:this.matric, //hantar matric
          });
  }
  
  goToMSelf(){
    this.navCtrl.push(MSelfPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }
  
  goToMRuasa(){
    this.navCtrl.push(MRuasaPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }

  goToMSession(){
    this.navCtrl.push(MSessionPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }

  goToMView(){
    this.navCtrl.push(MViewPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }

  goToUser(){
    this.navCtrl.push(UserPage                                            ,{
            matric:this.matric,
          }); 
  }

  /*
  goToUser(params){
    if (!params) params = {};
    this.navCtrl.push(UserPage);
  }goToMSelf(params){
    if (!params) params = {};
    this.navCtrl.push(MSelfPage);
  }goToMRuasa(params){
    if (!params) params = {};
    this.navCtrl.push(MRuasaPage);
  }goToMSession(params){
    if (!params) params = {};
    this.navCtrl.push(MSessionPage);
  }goToMView(params){
    if (!params) params = {};
    this.navCtrl.push(MViewPage);
  }
  */
}
