import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RHomePage } from '../r-home/r-home';
import { RGroupPage } from '../r-group/r-group';

@Component({
  selector: 'page-r-view',
  templateUrl: 'r-view.html'
})
export class RViewPage {

 /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

   /**
    * @name items
    * @type {Array}
    * @public
    * @description    The list of Session
    */

	 public matric    :  string;
   public sessions  :  Array<any> = [];


  constructor(public navCtrl    : NavController, 
              public NP         : NavParams,
              public toastCtrl  : ToastController,
              public http       : HttpClient,
              public navParams  : NavParams) {

      this.matric = navParams.get('matric');
      console.log(this.matric);

  }

  ionViewDidLoad() {
      //console.log("hi");
      //get the session list once the page is loaded
      let headers   : any    = new HttpHeaders({ 'Content-Type': 'application/json' }),
          options   : any    = { "key" : "getRView"},
          url       : any    = this.baseURI + "retrieve-data.php";

          this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
        {
          //console.dir(data);
          this.sessions =data;
        },
        (error : any) =>
        {
           this.sendNotification('Get Record Failed');
        });
    }

    sendNotification(message : string)  : void{
        let notification = this.toastCtrl.create({
            message       : message,
            duration      : 3000
        });
        notification.present();
    }

    itemSelected(item: string) {
      console.log("Selected Item", item);
    }


    goToHome(){
      this.navCtrl.push(RHomePage);
    }

    goToMView(){
      this.navCtrl.push(RGroupPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }
}
