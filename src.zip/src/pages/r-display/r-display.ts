import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { HttpClient, HttpHeaders } from '@angular/common/http';  
import { BarcodeScanner } from '@ionic-native/barcode-scanner';

import { RHomePage } from '../r-home/r-home';
import { RUpdatePage } from '../r-update/r-update';

@Component({
  selector: 'page-r-display',
  templateUrl: 'r-display.html'
})
export class RDisplayPage {

  session_id:string;
  createdCode = null;


  constructor(public navCtrl: NavController,
              private barcodeScanner: BarcodeScanner,
              public navParams: NavParams) {
    this.session_id = navParams.get('session_id');

    this.createdCode = this.session_id.toString();
    //console.log(this.session_id);
  }

  /*goToUpdate(){
    this.navCtrl.push(RUpdatePage);
  }*/

  goToRHome(params){
    if (!params) params = {};
    this.navCtrl.push(RHomePage);
  }
}
