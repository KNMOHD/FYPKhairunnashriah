import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { MHomePage } from '../m-home/m-home';

@Component({
  selector: 'page-m-session',
  templateUrl: 'm-session.html'
})

export class MSessionPage {

  matric:string;
  scannedCode = null;

  /**
    * @name baseURI
    * @type {String}
    * @public
    * @description     Remote URI for retrieving data from and sending data to
    */
   private baseURI               : string  = "http://idlanzikri.com/";

  constructor(public navCtrl        : NavController,
              private barcodeScanner: BarcodeScanner,
              public navParams      : NavParams,
              public fb             : FormBuilder,
              public toastCtrl      : ToastController,
              public http           : HttpClient) {
    this.matric = navParams.get('matric'); //hantar matric

    console.log(this.matric);
  }
  
  ionViewWillEnter(){
    this.sendNotification
  }

  scanCode() {
    this.barcodeScanner.scan().then(barcodeData => {this.scannedCode = barcodeData.text});

    let   scan    = this.scannedCode,
          matric  = this.matric,

    //setting the connection
    headers       : any = new HttpHeaders({ 'Content-Type': 'application/json'}),
    options       : any = { "key" : "scanAttendance", "scan":scan, "matric":matric},
    url           : any = this.baseURI + "retrieve-data.php";

    this.http.post(url, JSON.stringify(options), headers).subscribe((data : any) =>
    {
      this.sendNotification(data.message);
    }, (err) => {
        console.log('Error: ', err);
    });
  }

  /**
    * Manage notifying the user of the outcome of remote operations
    *
    * @public
    * @method sendNotification
    * @param message   {String}       Message to be displayed in the notification
    * @return {None}
    */
   sendNotification(message : string)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 10000
      });
      notification.present();
  }

    goToMHome(params){
    if (!params) params = {};
    this.navCtrl.push(MHomePage);
  }
}