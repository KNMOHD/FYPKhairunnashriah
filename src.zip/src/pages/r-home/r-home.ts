import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { UserPage } from '../user/user';
import { RLoginPage } from '../r-login/r-login';
import { RGroupPage } from '../r-group/r-group';
import { RSelfPage } from '../r-self/r-self';
import { RUpdatePage } from '../r-update/r-update';
import { RSessionPage } from '../r-session/r-session';
import { RMarusPage } from '../r-marus/r-marus';
import { RMarspecPage } from '../r-marspec/r-marspec';
import { RViewPage } from '../r-view/r-view';
import { RDisplayPage } from '../r-display/r-display';

@Component({
  selector: 'page-r-home',
  templateUrl: 'r-home.html'
})
export class RHomePage {

  matric:string;

  constructor(public navCtrl: NavController,
              public navParams: NavParams) {
    this.matric = navParams.get('matric');

    console.log(this.matric);
  }


  goToRSelf(){
    this.navCtrl.push(RSelfPage,{
            matric:this.matric, //hantar matric
          });
  }
  
  goToRMarus(){
    this.navCtrl.push(RMarusPage                                         ,{
            matric:this.matric, //hantar matric
          });
  }

  goToRSession(){
    this.navCtrl.push(RSessionPage                                            ,{
            matric:this.matric, //hantar matric
          });
  }

  goToRView(){
    this.navCtrl.push(RViewPage                                            ,{
            matric:this.matric, //hantar matric
          }); 
  }

  goToUser(){
    this.navCtrl.push(UserPage                                            ,{
            matric:this.matric,
          }); 

}
}