import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { RLoginPage } from '../r-login/r-login';
import { MLoginPage } from '../m-login/m-login';

@Component({
  selector: 'page-user',
  templateUrl: 'user.html'
})
export class UserPage {

  constructor(public navCtrl: NavController) {
  }


  goToRLogin(params){
    if (!params) params = {};
    this.navCtrl.push(RLoginPage);
  }goToMLogin(params){
    if (!params) params = {};
    this.navCtrl.push(MLoginPage);
  }
}
