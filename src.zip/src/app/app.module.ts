import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { MyApp } from './app.component';
import { UserPage } from '../pages/user/user';
import { RLoginPage } from '../pages/r-login/r-login';
import { MLoginPage } from '../pages/m-login/m-login';
import { RHomePage } from '../pages/r-home/r-home';
import { MHomePage } from '../pages/m-home/m-home';
import { RGroupPage } from '../pages/r-group/r-group';
import { MGroupPage } from '../pages/m-group/m-group';
import { MEnrollPage } from '../pages/m-enroll/m-enroll';
import { RMarusPage } from '../pages/r-marus/r-marus';
import { MRuasaPage } from '../pages/m-ruasa/m-ruasa';
import { RViewPage } from '../pages/r-view/r-view';
import { MViewPage } from '../pages/m-view/m-view';
import { RSelfPage } from '../pages/r-self/r-self';
import { MSelfPage } from '../pages/m-self/m-self';
import { RUpdatePage } from '../pages/r-update/r-update';
import { RSessionPage } from '../pages/r-session/r-session';
import { MSessionPage } from '../pages/m-session/m-session';
import { RMarspecPage } from '../pages/r-marspec/r-marspec';
import { RDisplayPage } from '../pages/r-display/r-display';


import { NgxQRCodeModule } from 'ngx-qrcode2';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';

@NgModule({
  declarations: [
    MyApp,
    UserPage,
    RLoginPage,
    MLoginPage,
    RHomePage,
    MHomePage,
    RGroupPage,
    MGroupPage,
    MEnrollPage,
    RMarusPage,
    MRuasaPage,
    RViewPage,
    MViewPage,
    RSelfPage,
    MSelfPage,
    RUpdatePage,
    RSessionPage,
    MSessionPage,
    RMarspecPage,
    RDisplayPage
  ],
  imports: [
    BrowserModule,
    NgxQRCodeModule,
    HttpModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    UserPage,
    RLoginPage,
    MLoginPage,
    RHomePage,
    MHomePage,
    RGroupPage,
    MGroupPage,
    MEnrollPage,
    RMarusPage,
    MRuasaPage,
    RViewPage,
    MViewPage,
    RSelfPage,
    MSelfPage,
    RUpdatePage,
    RSessionPage,
    MSessionPage,
    RMarspecPage,
    RDisplayPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    BarcodeScanner
  ]
})
export class AppModule {}